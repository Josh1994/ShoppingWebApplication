var bodyParser = require('body-parser');
var pg = require('pg');
var express = require('express');

var app = express();
var port = process.env.PORT || 8080;

var connectionString = "postgres://thriftfran:12345@depot:5432/thriftfran_jdbc";
var client = new pg.Client(connectionString);
client.connect(function (e) {
	if(e) {
		console.log("error on connection");
		console.log(e);
	} else {
		console.log("connection successful");
		initialiseTable();
	}
});



app.use(express.static('project1'));
app.use(bodyParser.json());



app.post('/todo/create/:task', function(req, res){
	var query = client.query("INSERT INTO todo (item, done) values ($1, false) RETURNING *", [req.params.task],  function(err, result){
		if(err){
			console.log(err);
			console.log("CREATION NOT SUCCESSFUL");
		} else {	
		res.send({
			id: result.rows[0].id,
			task: req.body.task
		});
		
		}
	});
});

app.put('/todo/update/:taskName/:id', function(req, res){
		var query = client.query("UPDATE todo SET item = '" + req.params.task + "' WHERE ID = " + req.params.id, function(err, result){
			if(err){
				console.log(err);		
				console.log("EDIT NOT SUCCESSFUL");
			} else {
				console.log("EDIT SUCCESSFUL");
			}		
		});
});

app.put('/todo/done/:id', function(req, res){
	console.log(req.body.id);
	var query = client.query("UPDATE todo SET done = true WHERE ID = " + req.params.id, function(err, result){
			if(err){
				console.log(err);		
				console.log("EDIT NOT SUCCESSFUL");
			} else {
				console.log("EDIT SUCCESSFUL");
			}		
		});
});

app.delete('/todo/kill/:id', function(req, res){
	var query = client.query("DELETE FROM todo WHERE id = $1", [req.params.id], 
	function(err, result){
		if(err){
			console.log(err);		
			console.log("DELETE NOT SUCCESSFUL");
		} else {
			console.log("DELETE SUCCESSFUL");
			res.send({success: true});
		}
		
	});
	
	
});

app.get('/todo/get', function(request, response) {
 var query = client.query("SELECT * FROM todo");
 var results = [];
 // Stream results back one row at a time
 query.on('row', function(row) {
 	results.push(row);
 });
 
 // After all data is returned, close connection and return results
 query.on('end', function() {
 	response.send(results);
 });
 
});
function initialiseTable(){
	var query = client.query('create table if not exists todo (id serial primary key, item varchar(255), done boolean)');
	
}
