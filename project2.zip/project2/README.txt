(A)
How to set up database:
need postgres
createdb thriftfran_jdbc
psql thriftfran_jdbc
password:12345
My program creates a todo table automatically if there is none present. 
I attempted parts Core and Completion apart from the CURL tests as they refused to 
work on the ECS machines. 

The todo.js uses ajax methods whenever: a new list item is created, 
a list item is deleted, 
a item list description is edited, 
a list item is checked "done".
One of the principals of using a restful design is that the URL is used to address a 
resource, not an action. As such the url's I used included the id's and tasknames needed
for each REST "app." function.

The error handling my program is very basic; it detects whether
there was an error on any of the rest app. calls, and if there is one it prints it out.
If not it continues the program. 

