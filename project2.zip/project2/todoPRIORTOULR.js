$(document).ready(function(e) {
	/*
		Ajax get method which delegates the work of adding the html code to the page. 
	*/
	$.ajax({
		method: 'GET',
 		url: 'http://localhost:8080/todo/get',
 	}).then(function showList(data) {
 		data.forEach(function(todo) {
 			appendTodoItemToList(todo.item, todo.id, todo.done);
		});
	});
	
	var ERROR_LOG = console.error.bind(console);
	var listElement = undefined;
	var editListElement = undefined;
	
	$('#add-todo').button({
		icons: { 
			primary: "ui-icon-circle-plus" 
		}
	}).click(function() {
		$('#new-todo').dialog('open');
	});

	$('#new-todo').dialog({
		modal : true, 
		autoOpen : false,
		buttons : {
		"Add task" : function () {
			$(this).dialog('close');
			 
			var taskName = $('#task').val();
			if (taskName === "") { 
				return false; 
			}
			$.ajax({
 				method: 'POST',
 				url: '/todo/create',
 				data: JSON.stringify({ task: taskName }),
				contentType: "application/json",
				dataType: "json",
				success : function (response) {
					appendTodoItemToList(response.task, response.id);
				}
			});
		 }, 
		 "Cancel" : function () { 
		 		$(this).dialog('close');
		 	} 
		 }
	});s
	
	
	function appendTodoItemToList(taskName, taskId, taskDone) {
		if(!taskDone){
			var taskHTML = '<li><span class="done">%</span>';
			taskHTML += '<span class = "edit">+</span>';
			taskHTML += '<span class="delete">x</span>';
			taskHTML += '<span class="task"></span></li>';
			var $newTask = $(taskHTML);
			$newTask.find('.task').text(taskName);
			$newTask.find('.task').attr('data-id', taskId);
			$newTask.hide();
			$('#todo-list').prepend($newTask);
			$newTask.show('clip',250).effect('highlight',1000);
		} else {
			var taskHTML = '<li><span class="done">%</span>';
			taskHTML += '<span class="delete">x</span>';
			taskHTML += '<span class="task"></span></li>';
			var $newTask = $(taskHTML);
			$newTask.find('.task').text(taskName);
			$newTask.find('.task').attr('data-id', taskId);
			$newTask.hide();
			$('#completed-list').prepend($newTask);
			$newTask.show('clip',250).effect('highlight',1000);	
		}
	}	
	
	
	$('#todo-list').on('click', '.done', function() {
		
		var $taskItem = $(this).parent('li');
		var id = $(this).parent('li').find('.task').attr('data-id');
		$taskItem.slideUp(250, function() {
		var $this = $(this);
		$this.detach();
		$('#completed-list').prepend($this);
		$this.slideDown();
		});
		
		$.ajax({
 			method: 'PUT',
 			url: 'http://localhost:8080/todo/done',
 			data: JSON.stringify({ id: id }),
			contentType: "application/json",
			dataType: "json"
		});
	});

	$('.sortlist').sortable({
		connectWith : '.sortlist',
		cursor : 'pointer',
		placeholder : 'ui-state-highlight',
		cancel : '.delete,.done'
		});

	$('.sortlist').on('click','.delete',function(){
		listElement = $(this).parent('li');
    	$('#confirm-delete').dialog('open');
	});

	$('#confirm-delete').dialog({  
  		modal : true,
  		autoOpen : false, 
    	buttons : { 
			"Confirm" : function (){
				var id = listElement.find('.task').attr('data-id');
	  		 	$.ajax({
 					method: 'DELETE',
 					url: 'http://localhost:8080/todo/kill',
 					data: JSON.stringify({ id: id }),
					contentType: "application/json",
					dataType: "json"
				});
								
				listElement.effect('puff', function() { 
					$(this).remove(); 
				});
				
				$(this).dialog('close');
	  		 
			},
			"Cancel" : function () { 
				$(this).dialog('close');
			} 
		}
	});

	$('.sortlist').on('click', '.edit', function(){
		editListElement = $(this).parent('li');
		$('#edit-todo').dialog('open');
	});

	$('#edit-todo').dialog({
		modal : true, autoOpen : false,
		buttons : {
			"Edit Task" : function (){
				var taskName = $('#edit').val();
				var id = editListElement.find('.task').attr('data-id');
				if (taskName === "") { 
					return false; 
				}
				$.ajax({
 					method: 'PUT',
 					url: 'http://localhost:8080/todo/update/',
 					data: JSON.stringify({ task: taskName, id: id}),
					contentType: "application/json",
					dataType: "json"
				});
				
				editListElement.find('span.task').text(taskName);
	  		 	$(this).dialog('close');
				
		 }, 
		 	"Cancel" : function () { $(this).dialog('close');} }
	});
	
	
}); // end ready